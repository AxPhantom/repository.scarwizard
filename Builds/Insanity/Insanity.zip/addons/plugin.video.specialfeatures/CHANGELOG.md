### Release (Official) 3.0.3 (041618) ###
* Added: Support for custom thumbnails
* Added: Special Features media flag
* Fixed: UTF-8 filename support
* Improved: Code quality

### Release (Official) 3.0.2 (031718) ###
* Fixed: Updating formatting to pep8

### Release (Official) 3.0.1 (031718) ###
* Fixed: Language formatting

### Release (Official) 3.0.0 (031418) ###
* Submitted to Official Kodi Repo

### Release Beta 2.0.9 (031318) ###
* Added: ListItem.Property(PlayAll)
* Fixed: Context menu bug

### Release Beta 2.0.7 (031118) ###
* Fixed: Home playall item to play first item in playlist
* Fixed: Database Cleaner
* Fixed: General bugfixes

### Release Beta 2.0.6 (031018) ###
* Fixed: Home screen support for context menu, widget and video info
* Fixed: CPU load issues
* Fixed: General bugfixes

### Release Beta 2.0.5 (030918) ###
* Added: Widget
* Added: Re-added context menu item
* Updated: Properties nomenclature
* Fixed: General bugfixes

### Release Beta 2.0.4 (030818) ###
* Added: Skin patches (props @evertiro)
* Updated: Properties nomenclature
* Fixed: Window returning to show on exit

### Release Beta 2.0.2 (021618) ###
* Added: TV Show support
* Added: .sfnfo support and editor
* Added: Show All option
* Added: Re-added information view service

### Release Beta 2.0.1 (020618) ###
* Added: Initial SQL support
* Removed: Context menu service
* Removed: Information view service

### Release Beta 2.0.0 (011818) ###
* Added: Auto scan/clean
* Fixed: Playlist lag
* Updated: Codebase overhaul

### Release Beta 1.0.2 (011418) ###
* Added: Krypton support

### Release Beta 1.0.1 (011418) ###
* Added: Play All list option
* Added: Option to disable Play All list (true by default)
* Updated: Rollback .json to 8.0

### Release Beta 1.0.0 (011318) ###
* Added: Initial public beta

### Release 0.0.1 (010818) ###
* Initialize plugin on Github
